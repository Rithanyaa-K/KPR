window.onload = function() {
    displayContacts();
};

function addContact() {
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();

    if (name === "" || phone === "") {
        alert("Please fill in both fields!");
        return;
    }

    let contacts = JSON.parse(localStorage.getItem('contacts')) || [];
    contacts.push({ name, phone });
    localStorage.setItem('contacts', JSON.stringify(contacts));

    document.getElementById('name').value = "";
    document.getElementById('phone').value = "";

    displayContacts();
}

function displayContacts() {
    const tbody = document.querySelector('#contactTable tbody');
    let contacts = JSON.parse(localStorage.getItem('contacts')) || [];
    tbody.innerHTML = "";

    contacts.forEach((contact, index) => {
        let row = tbody.insertRow();
        row.insertCell(0).innerText = contact.name;
        row.insertCell(1).innerText = contact.phone;
        let deleteBtn = document.createElement('button');
        deleteBtn.innerText = "Delete";
        deleteBtn.onclick = () => deleteContact(index);
        row.insertCell(2).appendChild(deleteBtn);
    });
}

function deleteContact(index) {
    let contacts = JSON.parse(localStorage.getItem('contacts')) || [];
    contacts.splice(index, 1);
    localStorage.setItem('contacts', JSON.stringify(contacts));
    displayContacts();
}
